/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bancoaula2;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cliente cli = new Cliente(1, "Pedro Junior", "cli@gmail.com", "123.456.789-10");
        Conta c = new Conta(123, cli, 500);
        Conta c1 = new Conta(134, new Cliente(2, "Rafa", "cli2@gmail.com", "526.456.985-00"), 250);
   
        System.out.println(c.mostraDados());
        System.out.println(c1.mostraDados());
        
        Funcionario f = new Funcionario(1000);
        
    }
    
}
