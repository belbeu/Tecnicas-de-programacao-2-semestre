/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoaula2;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Funcionario {
    public double salario= 1.500;
    
    //construtor
    public Funcionario (double salario) {
    this.salario = salario;
    }
    
    public void recebeAumento (double percentual) {
        double aumento;
        aumento = this.salario*(percentual/100);
        
    }
    
    public double ganhoAnual() {
        return this.salario*12;
    }
}
