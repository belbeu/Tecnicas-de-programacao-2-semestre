/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoaula2;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Cliente {
   public int idCliente;
   public String nome;
   public String cpf;
   public String eMail;
   
   Cliente( int id, String nome, String cpf, String eMail){
       
       this.idCliente = id;
       this.cpf = cpf;
       this.nome = nome;
       this.eMail = eMail;
       
   }
           
   public String mostraDados() {
   return "\n Cliente numero: " +this.idCliente+
           "\n Nome: " +this.nome+
           "\n Cpf: " +this.cpf+
           "\n Email: " +this.eMail;
   }
}
