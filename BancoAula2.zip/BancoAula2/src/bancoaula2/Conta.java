/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bancoaula2;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Conta {
    //atributos
    public int numeroConta;
    public Cliente titular;
    public double saldo=0;
    
    public Conta (int n, Cliente titular, double saldo){
    this.numeroConta = n;
    this.titular = titular;
    this.saldo = saldo;  
    }
    
    //métodos
    public void depositar(double valor) {
    this.saldo += valor; // saldo recebe saldo + valor
    }
    
    public boolean sacar(double valor) {
        if(this.saldo >= valor) {
        this.saldo -= valor;
        return true;
    }else{
         return false;   
        }
    }
    
    public boolean transferir (double valor, Conta c) {
    if(this.saldo >= valor) {
        this.sacar(valor);
        c.depositar(valor);
        return true;
    }else {
    return false;
        }
    }
    
    public String mostraDados() {
    return "\n Conta Número: " + this.numeroConta +
            "\n Titular: " + this.titular.mostraDados() +
            "\n Saldo R$: " + this.saldo;
    }
}
